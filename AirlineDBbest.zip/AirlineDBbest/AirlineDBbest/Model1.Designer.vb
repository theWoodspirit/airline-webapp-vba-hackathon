﻿' Die T4-Codegenerierung ist für Modell 'C:\UserData\z00430rr\Documents\GitHub\airline\AirlineDBbest\AirlineDBbest\Model1.edmx' aktiviert. 
' Um die Generierung von Legacycode zu aktivieren, ändern Sie den Wert der Designer-Eigenschaft 'Code Generation Strategy'
' in 'Legacy ObjectContext'. Diese Eigenschaft wird im Eigenschaftenfenster angezeigt, wenn das Modell
' im Designer geöffnet ist.

' Wenn keine Kontextklasse und keine Entitätsklassen generiert wurden, kann dies daran liegen, dass Sie ein leeres Modell erstellt, aber
' noch nicht die gewünschte Entity Framework-Version ausgewählt haben. Um eine Kontextklasse und
' Entitätsklassen für das Modell zu generieren, öffnen Sie das Modell im Designer, klicken mit der rechten Maustaste auf die Designeroberfläche, und
' wählen 'Modell aus der Datenbank aktualisieren', 'Datenbank aus Modell generieren' oder 'Codegenerierungselement
' hinzufügen' aus.